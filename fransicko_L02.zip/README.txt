Author: Michael Villafuerte

Q1: the image is included in the file: buildings.png

Q2: 8

Q3: The write-up was good for this lab.

Q4: 5 hours

Q5: No