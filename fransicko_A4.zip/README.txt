Michael Villafuerte
A4: Sell Out

Program Description:
This code will display a vechicle with a mascot floating around the vechicle following a Bezier curve.

Usage:
	W, S - Move the car forward and backwards.
	A, D - Turn the direction of the car left or right.
	Mouse drag - move the camera.
	SHIFT + Mouse drag - zoom in or out.
	NUM 1: Turn the control cage on or off.
	NUM 2: Turn the control points on or off.
	NUM 3: Turn the Bezier curve on or off.

Time: ~7hrs
lab: The lab prior to this assignment didn't havve anything to do with this lab.
Fun: 8
