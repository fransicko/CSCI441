CSCI441, Computer Graphics, Fall 2017
Michael Villafuerte

Q1: 9
Q2: The write up was very good for this lab.
Q3: it took me 1hr and 20mins
