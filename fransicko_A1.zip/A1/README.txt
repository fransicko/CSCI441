Michael Villafuerte A.K.A Fransicko

Assignment 1 - Hoist The Sign

This program creates a 700x150 window which displays my heros name and his crest.

To run this program simply run the .exe in power shell.

There are no bugs with this program.

This assignment took me 5 hrs to complete.

The lab helped me a great deal: 8

This assignment was a 8 of 10 on the fun scale.