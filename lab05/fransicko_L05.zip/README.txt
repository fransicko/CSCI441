CSCI441, Computer Graphics, Fall 2017
Michael Villafuerte

Q1. The teapot looks like it was made with bricks.

Q2. All the other images where textured as well.

Q3. It looks a bit dark but if i switch between some objects it gets light added to it.

Q4. The teapot is mines up.

Q5. The image is on my quad and it is oriantated correctly.

Q6. There are now four mines log appearing on the block

Q7. 8
Q8. The right up was good
Q9. 3hrs
Q10. No