Author: Michael Villafuerte, mvillafu@mymail.mines.edu
Assignment 3: Enter the Park

So this program builds the layout of the park. There are pyramids and a car object that the user can control with wasd and the left mouse button along with ctrl left mouse button.

The user simply has to press the W key to go forward, S to go backwards, A and D to change the the angle the car is facing. You move around the car by left click and draggin the mouse.
If you hold either of the ctrl keys and drag the mouse you can zoom in on the car or out.

Simply type make and run a3.exe to compile.

The only bug is that teh camera starts looking down at the car. But simply clikcing the screen will recet it

Time: ~6 hrs

The lab helped me 80% of the way to completing this assignment.

Fun: 10, i wished i invested more time in to this.