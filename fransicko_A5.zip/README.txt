Author: Michael Villafuerte

Assignment 5: The Main Attraction

DESCRIPTION
	This program will display a user inputted object file surrounded by a sky box.
	The object will undergo the Blinn-Phong shading model.
	
USAGE
	Simply tip 'make' and run ./a5.exe <file>.object.
	Hold ctrl+left click to zoom in and out.
	
	
This assignment took about 12~ hrs.
The labs were the foundation for this assignment 10.
Since I turned in this lab late it helped me to learn shaders so 8.

