var files_dup =
[
    [ "objects.hpp", "objects_8hpp.html", "objects_8hpp" ],
    [ "OpenGLUtils.hpp", "_open_g_l_utils_8hpp.html", "_open_g_l_utils_8hpp" ],
    [ "teapot.hpp", "teapot_8hpp.html", null ]
];