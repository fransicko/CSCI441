Author: Michael Villafuerte

Q1 : They roll out of the plat form and into the sunset going through one another.

Q2 : They stay withing the ground. (1,0,0) (-1,0,0) (0,0,1) (0,0,-1)

Q3 : we calculae the distance between the two spheres and normalize them to get the normals. L12 = normalize(L2 - L1) L21 = normalize(L1 - L2)

Q4 : There is the bug where the marbles will travel with eachother and where they get stuck on one another.

Q5 : 8
Q6 : The write up wa perfect.
Q7 : 1hr
Q8 : Nope.