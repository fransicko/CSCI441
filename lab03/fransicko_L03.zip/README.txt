CSCI441, Computer Graphics, Fall 2017
Michael Villafuerte

Q1: 8
Q2: The write up was good.
Q3: ~3hrs