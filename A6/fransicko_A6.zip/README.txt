Author: Michael Villafuerte
Assignment 6

DESCRIPTION:
	This program will read in a txt file that will specify a location for
	snowflakes to start falling down from a fountain at the given speed and frequency.
	
USAGE:
	To run this program simply make the program and provide it a valid 
	txt file.
	


NOTES: 
	This program does not continuouslt produce snowflakes. Instead what it does is that at 
	the start it will wait a certain amount of seconds then produce the specified amount of 
	snowflakes that the user has per second at once then wait till they die to produce another set.
	
TIME:
	15+hrs
	
The labs from the billboarding was what i used to start with plus assignment 5.
Fun: 7

	