var searchData=
[
  ['numteapotpoints',['NumTeapotPoints',['../teapot_8hpp.html#a492c787e82b3162ee95b0744510d9a4c',1,'teapot.hpp']]]
];
