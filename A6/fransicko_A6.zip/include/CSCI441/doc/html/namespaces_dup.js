var namespaces_dup =
[
    [ "CSCI441", "namespace_c_s_c_i441.html", null ]
];